package de.schrieverkommt;


import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Timer;
import java.util.TimerTask;
import com.sun.nio.sctp.Notification;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;




public class FXMLController {
	
	@FXML private CheckBox aktivBox;
	@FXML private Label letzteAkt;
	@FXML private Button ausfuehren;
	@FXML private Button anleitung;
	@FXML private Button info;
	@FXML private Button hintergrund;
	@FXML private Pane pane;
	
	TrayIcon trayIcon;
	int stateWindow = 0;
	
	@FXML protected void hintergrundKlick(ActionEvent event) {
		
		Stage stage =(Stage)pane.getScene().getWindow();
		stage.hide();
		
		
		if (SystemTray.isSupported()) {         
            SystemTray tray = SystemTray.getSystemTray();
            Image image = Toolkit.getDefaultToolkit().getImage("C:\\Users\\oschr\\Desktop\\aa.png");
            PopupMenu popup = new PopupMenu();
            MenuItem item = new MenuItem("Exit");

            popup.add(item);

           trayIcon = new TrayIcon(image, "Anomaly Refresh by Schriever kommt", popup);
           
            ActionListener listener = new ActionListener() {                
                @Override
                public void actionPerformed(java.awt.event.ActionEvent event) {
                	
                	
                    System.exit(0);                 
                }               
            }; 
            
            
            

    		trayIcon.addMouseListener(new MouseAdapter() {
    		    @Override
    		    public void mouseClicked(MouseEvent event) {
    		        if (event.getButton() == MouseEvent.BUTTON1) {
    		            Platform.runLater(new Runnable() {
    		                @Override
    		                public void run() {
    		                    if (stateWindow == 1) {
    		                        stage.hide();
    		                        stateWindow = 0;
    		                    } else if (stateWindow == 0) {
    		                        stage.show();
    		                        stateWindow = 1;
    		                    }
    		                }
    		            });
    		        }

    		    }
    		});
            
        
//            ActionListener listenerTray = new ActionListener() {                
//                @Override
//                public void actionPerformed(java.awt.event.ActionEvent arg0) {
//                	
//								System.out.println("Doppelklick!!!");
//								
//                }                   
//            };            

//            trayIcon.addActionListener(listenerTray);
            item.addActionListener(listener);

            try{
              tray.add(trayIcon);
              trayIcon.displayMessage("Anomaly Refresh", "Die App wird im Hintergrund ausgef�hrt.", MessageType.INFO);
             
            }catch (Exception e) {
              System.err.println("Can't add to tray");
            }
          } else {
            System.err.println("Tray unavailable");
          } 
        
    
	
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	

		
	
	 @FXML protected void anleitungKlick(ActionEvent event) {
		//den Dialog erzeugen und anzeigen
			Alert meinDialog = new Alert(AlertType.INFORMATION, "Setzen sie im Informationsk�stchen den Haken, um eine w�chentliche Erneuerung der Anomaly-Database zu aktivieren.\nDieser Vorgang wird durch anklicken des Buttons ->jetzt Ausf�hren<- manuell gestartet.\nDurch klicken des Buttons ->Hintergrundmodus<- bleibt das Programm fortlaufend aktiv. Um eine korrekte Funktion zu gew�hrleisten, darf das Programm nicht geschlossen werden.");
			
			meinDialog.setTitle("Anleitung");
			//den Text setzen
			meinDialog.setHeaderText("Bitte beachten sie die folgenden Schritte:");
			//den Dialog anzeigen
			meinDialog.showAndWait();
	 }
	 
	 @FXML protected void infoKlick(ActionEvent event) {
			//den Dialog erzeugen und anzeigen
				Alert meinDialog = new Alert(AlertType.INFORMATION, "Version 1.1\n� Oliver Schriever, 06/2020");
				
				meinDialog.setTitle("Info");
				//den Text setzen
				meinDialog.setHeaderText("Anomaly Refresh by Schrieverkommt");
				//den Dialog anzeigen
				meinDialog.showAndWait();
		 }
	 

	
	@FXML protected void aktivKlick(ActionEvent event) {
			Timer timer = new Timer();
			timer.scheduleAtFixedRate(new TimerTask() {
				
				@Override
				public void run() {
					if (aktivBox.isSelected()) {
					programmAusfuehren();
					}
					else {
						timer.cancel();
			}
					}
			}, 6*1000, 6*1000);
			
		
	
		
	}
	private void notification() {
		trayIcon.displayMessage("Anomaly Refresh by Schrieverkommt", "Die Anomaly Database wurde erneuert", MessageType.INFO);
	}
	
	@FXML protected void ausfuehrenKlick(ActionEvent event) {
		programmAusfuehren();
		
		
		 
	}
	
	 private void datumSetzen() {
	      LocalDate date = LocalDate.now();
		 String aktDatum;
	       DateTimeFormatter df;
	        df = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);      // Sonntag, 31. Januar 2016
	       
	        aktDatum = date.format(df);
	        letzteAkt.setText(aktDatum);
	    } 
	private void programmAusfuehren() {
		Path anomalyOld = Paths.get("C:\\Users\\oschr\\Desktop\\Anomaly old\\Anomaly.DB");
		Path anomalyNew = Paths.get("C:\\Users\\oschr\\Desktop\\Anomaly new\\Anomaly.DB");
		
		
		try {
			Files.copy(anomalyOld, anomalyNew, StandardCopyOption.REPLACE_EXISTING);
			
			System.out.println("Kopie wurde erstellt");
			datumSetzen();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
	}
	
}

