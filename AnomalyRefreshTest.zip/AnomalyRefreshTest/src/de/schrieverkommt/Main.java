package de.schrieverkommt;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application {

	
	@Override
	public void start(Stage meineStage) throws Exception {
		
		Parent root = FXMLLoader.load(getClass().getResource("sb_AnomalyRefresh.fxml"));
		
		
		
		Scene meineScene = new Scene(root, 656, 500);
		
		//den Titel über stage setzen
		meineStage.setTitle("Anomaly Refresh by Schrieverkommt");
		
		
		//die Szene setzen
		meineStage.setScene(meineScene);
		
		meineStage.show();
		
	}
	
	
	

	public static void main(String[] args) {
		launch(args);

		
		


	}
	

	

}
